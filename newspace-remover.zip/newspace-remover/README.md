How to use?
python newspace-remover.py -i <input file> -o <output file>

Input file - file you want to remove newspaces from
Output file - the resulting file after fix